﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project5
{
    
    public partial class Form1 : Form
    {
        double weight;
        double distance;
        double totalPrice;
        bool errorCheck = false;
        double upcharge;

        public Form1()
        {
            InitializeComponent();
        }
        

       private double UPSMethod(double weight, double distance)
        {
            

            if (distance <= 100)
                {
                    totalPrice = weight * 6.4;
                    return totalPrice;
                }
                else if (distance <= 500)
                {
                    totalPrice = weight * 5.75;
                    return totalPrice;
                }
                else
                {
                    totalPrice = weight * 4.5;
                    return totalPrice;
                }

        }
        private double FedexMethod(double weight, double distance)
        {

            if (distance <= 500)
            {
                totalPrice = weight * 4.75;
                return totalPrice;
            }
            else if (distance <= 1000)
            {
                totalPrice = weight * 9.75;
                return totalPrice;
            }
            else
            {
                totalPrice = weight * 14.5;
                return totalPrice;

            }
        }
    private double UspsMethod(double weight, double distance)
        {
            //Left Off here trying to add the upcharge price and the total price but only the upcharge price is showing
           if (distance > 500)
            {
                double upchargeprice;
                upcharge = 1.25;
                lblUpcharge.Text = ("You upcharge for the distance is: " + weight * 1.25);
            }
           //what the hell am i doing ^^
            if (weight <= 1)
                {
                    totalPrice = weight * 3.9;
                    return totalPrice;
                }
                else if (weight <= 10)
                {
                    totalPrice = weight * 1.75;
                    return totalPrice;
                }
               else if (weight > 25)
                {
                MessageBox.Show("USPS Package must not exceed 25 lbs");
                return totalPrice;
                }
                else
                   {
                        totalPrice = weight * 1.5;
                        return totalPrice;
                   }
           
              
    }
    
   

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        
        
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                weight = double.Parse(tbweight.Text);
                distance = double.Parse(tbDistance.Text);
            }
            catch
            {
                MessageBox.Show("You Must Enter numbers into the textbox");
            }

            errorCheckMethod(weight, distance);
            if (errorCheck == false)
            {
                if (radUPS.Checked == true)
                {
                    lblShippingCost.Text = UPSMethod(weight, distance).ToString("C");
                }
                else if (radFedex.Checked == true)
                {
                    lblShippingCost.Text = FedexMethod(weight, distance).ToString("C");
                }
                else
                {
                    lblShippingCost.Text = UspsMethod(weight, distance).ToString("C");
                }
            }
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            tbDistance.Clear();
            tbweight.Clear();
            totalPrice = 0;
            lblUpcharge.Text = "";
            lblShippingCost.Text = "$0.00";

        }

        private void errorCheckMethod(double weight, double distance)
        {
          
         
            if (radFedex.Checked==false && radUSPS.Checked==false && radUPS.Checked==false)
            {
                errorCheck = false;
                MessageBox.Show("Select a Carrier"); 
            }
            if (weight < 0 || distance < 0)
            {
                MessageBox.Show("ERROR Enter a Postive Number");
                errorCheck = false;
            }
        }

        private void tbweight_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblUpcharge_Click(object sender, EventArgs e)
        {

        }

        private void lblShippingCost_Click(object sender, EventArgs e)
        {

        }
    }
}
